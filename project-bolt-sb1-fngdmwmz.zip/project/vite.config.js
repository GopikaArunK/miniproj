export default {
  server: {
    open: true
  }
};