import React, { useState } from 'react';
import { AArrowDown as DNA, Scissors, Target, Beaker, ArrowDownCircle } from 'lucide-react';

interface PredictionFormData {
  targetGene: string;
  species: string;
  enzyme: string;
  modificationType: 'knockout' | 'knockin';
  sequence?: string;
}

function App() {
  const [formData, setFormData] = useState<PredictionFormData>({
    targetGene: '',
    species: '',
    enzyme: '',
    modificationType: 'knockout',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle prediction logic here
    console.log('Form submitted:', formData);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-blue-100">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
          <div className="flex items-center space-x-3">
            <DNA className="h-10 w-10 text-indigo-600 animate-pulse" />
            <div>
              <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600">
                CRISPR Efficiency Predictor
              </h1>
              <p className="text-gray-600 text-sm mt-1">
                Optimize your gene editing experiments with AI-powered predictions
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-3xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="bg-white/70 backdrop-blur-sm rounded-3xl shadow-xl border border-blue-100">
          <div className="p-8">
            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Target Gene Selection */}
              <div className="group">
                <label className="flex items-center text-sm font-medium text-gray-700 mb-2 group-hover:text-indigo-600 transition-colors">
                  <Target className="h-5 w-5 mr-2 group-hover:text-indigo-600 transition-colors" />
                  Target Gene
                </label>
                <select
                  value={formData.targetGene}
                  onChange={(e) => setFormData({ ...formData, targetGene: e.target.value })}
                  className="mt-1 block w-full pl-3 pr-10 py-3 text-base border-gray-200 bg-white/50 backdrop-blur-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent sm:text-sm rounded-xl transition-all hover:bg-white"
                >
                  <option value="">Select Target Gene</option>
                  <option value="BRCA1">BRCA1</option>
                  <option value="TP53">TP53</option>
                  <option value="EGFR">EGFR</option>
                  <option value="KRAS">KRAS</option>
                </select>
              </div>

              {/* Species Selection */}
              <div className="group">
                <label className="flex items-center text-sm font-medium text-gray-700 mb-2 group-hover:text-indigo-600 transition-colors">
                  <Beaker className="h-5 w-5 mr-2 group-hover:text-indigo-600 transition-colors" />
                  Species
                </label>
                <select
                  value={formData.species}
                  onChange={(e) => setFormData({ ...formData, species: e.target.value })}
                  className="mt-1 block w-full pl-3 pr-10 py-3 text-base border-gray-200 bg-white/50 backdrop-blur-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent sm:text-sm rounded-xl transition-all hover:bg-white"
                >
                  <option value="">Select Species</option>
                  <option value="human">Human (Homo sapiens)</option>
                  <option value="mouse">Mouse (Mus musculus)</option>
                  <option value="rat">Rat (Rattus norvegicus)</option>
                  <option value="zebrafish">Zebrafish (Danio rerio)</option>
                </select>
              </div>

              {/* CRISPR Enzyme Selection */}
              <div className="group">
                <label className="flex items-center text-sm font-medium text-gray-700 mb-2 group-hover:text-indigo-600 transition-colors">
                  <Scissors className="h-5 w-5 mr-2 group-hover:text-indigo-600 transition-colors" />
                  CRISPR Enzyme
                </label>
                <select
                  value={formData.enzyme}
                  onChange={(e) => setFormData({ ...formData, enzyme: e.target.value })}
                  className="mt-1 block w-full pl-3 pr-10 py-3 text-base border-gray-200 bg-white/50 backdrop-blur-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent sm:text-sm rounded-xl transition-all hover:bg-white"
                >
                  <option value="">Select Enzyme</option>
                  <option value="spCas9">Streptococcus pyogenes Cas9 (SpCas9)</option>
                  <option value="saCas9">Staphylococcus aureus Cas9 (SaCas9)</option>
                  <option value="cpf1">Cas12a (Cpf1)</option>
                  <option value="cas13">Cas13</option>
                </select>
              </div>

              {/* Modification Type */}
              <div className="group">
                <label className="flex items-center text-sm font-medium text-gray-700 mb-2 group-hover:text-indigo-600 transition-colors">
                  <ArrowDownCircle className="h-5 w-5 mr-2 group-hover:text-indigo-600 transition-colors" />
                  Modification Type
                </label>
                <div className="mt-3 grid grid-cols-2 gap-4">
                  <label className="relative flex items-center justify-center p-4 border border-gray-200 rounded-xl cursor-pointer hover:border-indigo-500 transition-colors bg-white/50 backdrop-blur-sm">
                    <input
                      type="radio"
                      value="knockout"
                      checked={formData.modificationType === 'knockout'}
                      onChange={(e) => setFormData({ ...formData, modificationType: 'knockout' })}
                      className="form-radio h-4 w-4 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="ml-2">Knock-out</span>
                  </label>
                  <label className="relative flex items-center justify-center p-4 border border-gray-200 rounded-xl cursor-pointer hover:border-indigo-500 transition-colors bg-white/50 backdrop-blur-sm">
                    <input
                      type="radio"
                      value="knockin"
                      checked={formData.modificationType === 'knockin'}
                      onChange={(e) => setFormData({ ...formData, modificationType: 'knockin' })}
                      className="form-radio h-4 w-4 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="ml-2">Knock-in</span>
                  </label>
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-6">
                <button
                  type="submit"
                  className="w-full flex justify-center py-3 px-4 border border-transparent rounded-xl shadow-sm text-base font-medium text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all transform hover:scale-[1.02]"
                >
                  Predict Efficiency
                </button>
              </div>
            </form>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;