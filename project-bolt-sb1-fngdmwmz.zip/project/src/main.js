document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('predictionForm');
  const formPage = document.getElementById('formPage');
  const resultsPage = document.getElementById('resultsPage');
  const backButton = document.getElementById('backButton');
  let efficiencyChart = null;

  // Add hover effects for group labels
  document.querySelectorAll('.group').forEach(group => {
    const label = group.querySelector('label');
    const icon = label.querySelector('svg');
    
    group.addEventListener('mouseenter', () => {
      label.classList.add('text-indigo-600');
      icon.classList.add('text-indigo-600');
    });
    
    group.addEventListener('mouseleave', () => {
      label.classList.remove('text-indigo-600');
      icon.classList.remove('text-indigo-600');
    });
  });

  // Mock function to simulate efficiency prediction
  const predictEfficiency = (formData) => {
    return new Promise((resolve) => {
      setTimeout(() => {
        // Simulate API call with random efficiency score
        const efficiency = Math.random() * 100;
        resolve({
          efficiency,
          recommendations: [
            `Based on the analysis, the selected guide RNA sequence shows ${efficiency.toFixed(1)}% predicted efficiency.`,
            efficiency > 70 ? 'This is a highly efficient target site.' : 'Consider optimizing the target site for better efficiency.',
            `The ${formData.enzyme} enzyme typically performs well with ${formData.targetGene} in ${formData.species}.`,
            formData.modificationType === 'knockout' ? 
              'For knock-out experiments, consider using multiple guide RNAs to increase efficiency.' :
              'For knock-in experiments, ensure your donor template has sufficient homology arms.'
          ]
        });
      }, 1000);
    });
  };

  // Initialize efficiency chart
  const initializeChart = (efficiency) => {
    const ctx = document.getElementById('efficiencyChart').getContext('2d');
    
    if (efficiencyChart) {
      efficiencyChart.destroy();
    }

    efficiencyChart = new Chart(ctx, {
      type: 'doughnut',
      data: {
        datasets: [{
          data: [efficiency, 100 - efficiency],
          backgroundColor: [
            'rgb(79, 70, 229)',
            'rgb(229, 231, 235)'
          ],
          borderWidth: 0
        }]
      },
      options: {
        cutout: '80%',
        responsive: true,
        plugins: {
          legend: {
            display: false
          },
          tooltip: {
            enabled: false
          }
        },
        animation: {
          animateRotate: true,
          animateScale: true
        }
      }
    });

    // Add center text
    const centerText = {
      id: 'centerText',
      afterDatasetsDraw(chart) {
        const { ctx, data } = chart;
        ctx.save();
        
        const xCenter = chart.getDatasetMeta(0).data[0].x;
        const yCenter = chart.getDatasetMeta(0).data[0].y;
        
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.font = 'bold 24px Arial';
        ctx.fillStyle = '#1F2937';
        ctx.fillText(`${data.datasets[0].data[0].toFixed(1)}%`, xCenter, yCenter);
        
        ctx.font = '14px Arial';
        ctx.fillStyle = '#6B7280';
        ctx.fillText('Efficiency', xCenter, yCenter + 25);
        
        ctx.restore();
      }
    };

    efficiencyChart.config.options.plugins = {
      ...efficiencyChart.config.options.plugins,
      centerText
    };
    
    efficiencyChart.update();
  };

  // Update results page with form data
  const updateResults = (formData, predictionResults) => {
    document.getElementById('resultTargetGene').textContent = formData.targetGene;
    document.getElementById('resultSpecies').textContent = formData.species;
    document.getElementById('resultEnzyme').textContent = formData.enzyme;
    document.getElementById('resultModification').textContent = formData.modificationType;

    // Initialize the efficiency chart
    initializeChart(predictionResults.efficiency);

    // Update recommendations
    const recommendationsHtml = predictionResults.recommendations
      .map(rec => `<p class="mb-2">${rec}</p>`)
      .join('');
    document.getElementById('recommendations').innerHTML = recommendationsHtml;
  };

  // Handle form submission
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = {
      targetGene: form.targetGene.value,
      species: form.species.value,
      enzyme: form.enzyme.value,
      modificationType: form.modificationType.value
    };

    // Validate form
    if (!formData.targetGene || !formData.species || !formData.enzyme) {
      alert('Please fill in all required fields');
      return;
    }

    // Show loading state
    const submitButton = form.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    submitButton.textContent = 'Predicting...';
    submitButton.disabled = true;

    try {
      // Get prediction results
      const predictionResults = await predictEfficiency(formData);
      
      // Update results page
      updateResults(formData, predictionResults);
      
      // Show results page
      formPage.classList.add('hidden');
      resultsPage.classList.add('active');
    } catch (error) {
      console.error('Prediction failed:', error);
      alert('Failed to generate prediction. Please try again.');
    } finally {
      // Reset button state
      submitButton.textContent = originalText;
      submitButton.disabled = false;
    }
  });

  // Handle back button
  backButton.addEventListener('click', () => {
    formPage.classList.remove('hidden');
    resultsPage.classList.remove('active');
  });
});